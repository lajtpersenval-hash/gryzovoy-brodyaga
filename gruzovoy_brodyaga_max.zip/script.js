/* Грузовой Бродяга — интерфейс, калькулятор и подготовка формы заявки. */
(() => {
  'use strict';

  const RATE_BY_WORKERS = [0, 900, 875, 850, 825, 800, 800, 800, 800, 800, 800];
  const rubles = value => new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 }).format(value) + ' ₽';

  function plural(value, one, few, many) {
    const n10 = value % 10;
    const n100 = value % 100;
    if (n10 === 1 && n100 !== 11) return one;
    if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) return few;
    return many;
  }

  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const workersRange = $('#workersRange');
  const hoursRange = $('#hoursRange');
  const workersOutput = $('#workersOutput');
  const hoursOutput = $('#hoursOutput');
  const totalPrice = $('#totalPrice');
  const priceBreakdown = $('#priceBreakdown');
  const discountLabel = $('#discountLabel');
  const orderRecapText = $('#orderRecapText');
  const orderRecapPrice = $('#orderRecapPrice');
  const orderForm = $('#orderForm');
  const formStatus = $('#formStatus');
  const phoneInput = $('#phone');

  function readEstimate() {
    const workers = Number(workersRange.value);
    const hours = Number(hoursRange.value);
    const rate = RATE_BY_WORKERS[workers] || 800;
    const discount = 900 - rate;
    const total = workers * hours * rate;
    return { workers, hours, rate, discount, total };
  }

  function setRangeFill(input) {
    const min = Number(input.min);
    const max = Number(input.max);
    const value = Number(input.value);
    const percentage = ((value - min) / (max - min)) * 100;
    input.style.setProperty('--range-progress', `${percentage}%`);
  }

  function updateEstimate() {
    const estimate = readEstimate();
    const { workers, hours, rate, discount, total } = estimate;
    workersOutput.textContent = `${workers} ${plural(workers, 'грузчик', 'грузчика', 'грузчиков')}`;
    hoursOutput.textContent = `${hours} ${plural(hours, 'час', 'часа', 'часов')}`;
    totalPrice.textContent = rubles(total);
    priceBreakdown.textContent = `${rubles(rate)} × ${workers} ${plural(workers, 'человек', 'человека', 'человек')} × ${hours} ${plural(hours, 'час', 'часа', 'часов')}`;
    discountLabel.textContent = discount > 0
      ? `Скидка за команду: −${rubles(discount)} за человека/час`
      : 'Базовая ставка — без скидки';
    orderRecapText.textContent = `${workers} ${plural(workers, 'грузчик', 'грузчика', 'грузчиков')} · ${hours} ${plural(hours, 'час', 'часа', 'часов')} · ${rubles(rate)}/чел./час`;
    orderRecapPrice.textContent = rubles(total);
    setRangeFill(workersRange);
    setRangeFill(hoursRange);
    return estimate;
  }

  [workersRange, hoursRange].forEach(input => {
    input.addEventListener('input', updateEstimate);
    input.addEventListener('change', updateEstimate);
  });
  updateEstimate();

  $('#goToOrder').addEventListener('click', () => {
    updateEstimate();
    $('#order').scrollIntoView({ behavior: 'smooth', block: 'start' });
    window.setTimeout(() => $('[name="name"]').focus({ preventScroll: true }), 450);
  });

  // Выпадающее меню «Услуги» на широком экране.
  const dropdownToggle = $('.nav-dropdown-toggle');
  const dropdownPanel = $('#servicesMenu');
  function closeDropdown() {
    dropdownToggle.setAttribute('aria-expanded', 'false');
    dropdownPanel.hidden = true;
  }
  dropdownToggle.addEventListener('click', event => {
    event.stopPropagation();
    const isOpen = dropdownToggle.getAttribute('aria-expanded') === 'true';
    dropdownToggle.setAttribute('aria-expanded', String(!isOpen));
    dropdownPanel.hidden = isOpen;
  });
  document.addEventListener('click', event => {
    if (!event.target.closest('.nav-dropdown')) closeDropdown();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      closeDropdown();
      closeMobileMenu();
    }
  });

  // Меню для WebView и маленьких экранов.
  const menuToggle = $('#menuToggle');
  const mobileMenu = $('#mobileMenu');
  const mobileServicesToggle = $('#mobileServicesToggle');
  const mobileServicesSubmenu = $('#mobileServicesSubmenu');
  function closeMobileServices() {
    if (!mobileServicesToggle || !mobileServicesSubmenu) return;
    mobileServicesToggle.setAttribute('aria-expanded', 'false');
    mobileServicesSubmenu.hidden = true;
  }
  if (mobileServicesToggle && mobileServicesSubmenu) {
    mobileServicesToggle.addEventListener('click', () => {
      const isOpen = mobileServicesToggle.getAttribute('aria-expanded') === 'true';
      mobileServicesToggle.setAttribute('aria-expanded', String(!isOpen));
      mobileServicesSubmenu.hidden = isOpen;
    });
  }
  function closeMobileMenu() {
    if (!menuToggle || !mobileMenu) return;
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Открыть меню');
    mobileMenu.hidden = true;
    document.body.classList.remove('menu-open');
    closeMobileServices();
  }
  menuToggle.addEventListener('click', () => {
    const open = menuToggle.getAttribute('aria-expanded') !== 'true';
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    mobileMenu.hidden = !open;
    document.body.classList.toggle('menu-open', open);
  });
  $$('[data-close-menu]').forEach(link => link.addEventListener('click', () => {
    closeMobileMenu();
    closeDropdown();
  }));
  window.addEventListener('resize', () => {
    if (window.innerWidth > 720) closeMobileMenu();
  });

  // Маска телефона РФ. Валидируем 11 цифр с кодом страны 7.
  function formatRussianPhone(raw) {
    let digits = raw.replace(/\D/g, '');
    if (!digits) return '';
    if (digits.startsWith('8')) digits = '7' + digits.slice(1);
    if (!digits.startsWith('7')) digits = '7' + digits;
    digits = digits.slice(0, 11);
    const local = digits.slice(1);
    let result = '+7';
    if (local.length > 0) result += ' (' + local.slice(0, 3);
    if (local.length >= 3) result += ')';
    if (local.length > 3) result += ' ' + local.slice(3, 6);
    if (local.length > 6) result += '-' + local.slice(6, 8);
    if (local.length > 8) result += '-' + local.slice(8, 10);
    return result;
  }
  phoneInput.addEventListener('input', () => {
    const before = phoneInput.value;
    phoneInput.value = formatRussianPhone(before);
  });

  // Оплата намеренно не имитируется на клиенте. Позже сюда подключается backend.
  // Сервер обязан сам пересчитать тариф, создать платёж ЮKassa и вернуть confirmation_url.
  const PAYMENT_ENDPOINT = ''; // Например: '/api/create-payment' после запуска backend.

  orderForm.addEventListener('submit', async event => {
    event.preventDefault();
    if (!orderForm.reportValidity()) return;

    const phoneDigits = phoneInput.value.replace(/\D/g, '');
    if (phoneDigits.length !== 11 || !phoneDigits.startsWith('7')) {
      formStatus.textContent = 'Проверьте телефон: укажите полный номер в формате +7.';
      phoneInput.focus();
      return;
    }

    const estimate = updateEstimate();
    const payload = {
      name: String(orderForm.elements.name.value).trim(),
      phone: phoneInput.value,
      city: orderForm.elements.city.value,
      address: String(orderForm.elements.address.value).trim(),
      comment: String(orderForm.elements.comment.value).trim(),
      services: $$('input[name="service"]:checked').map(input => input.value),
      workers: estimate.workers,
      hours: estimate.hours,
      ratePerWorkerHour: estimate.rate,
      calculatedTotalRub: estimate.total,
      currency: 'RUB'
    };

    const submitButton = $('#submitOrder');
    if (!PAYMENT_ENDPOINT) {
      // Демо-режим: не отправляем персональные данные неизвестному адресу и не списываем деньги.
      formStatus.textContent = 'Форма и расчёт готовы. Отправка заявок и онлайн-оплата включатся после подключения защищённого сервера. Сейчас заказ не отправлен и деньги не списаны. Позвоните или напишите в MAX.';
      console.info('Заявка сформирована для интеграции backend. Сумма:', payload.calculatedTotalRub, 'RUB. Персональные данные не отправлены.');
      return;
    }

    submitButton.disabled = true;
    submitButton.textContent = 'Оформляем заказ…';
    formStatus.textContent = 'Передаём данные на защищённый сервер…';
    try {
      const response = await fetch(PAYMENT_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(`Ошибка сервера: ${response.status}`);
      const result = await response.json();
      if (typeof result.confirmation_url !== 'string' || !/^https:\/\//i.test(result.confirmation_url)) {
        throw new Error('Сервер не вернул безопасную ссылку оплаты.');
      }
      window.location.assign(result.confirmation_url);
    } catch (error) {
      console.error('Не удалось создать заказ:', error);
      formStatus.textContent = 'Не получилось оформить заказ. Проверьте соединение или свяжитесь с нами по телефону / MAX.';
      submitButton.disabled = false;
      submitButton.innerHTML = 'Отправить заявку <span>↗</span>';
    }
  });

  // Появление элементов при прокрутке. При reduced-motion анимация не задерживает контент.
  const revealItems = $$('.reveal');
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) {
    revealItems.forEach(item => item.classList.add('visible'));
  } else {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -25px 0px' });
    revealItems.forEach(item => observer.observe(item));
  }

  // Intro: коробка подпрыгивает, затем появляется лайк и надпись ГОТОВО.
  const bootScreen = $('#bootScreen');
  const bootBox = $('#bootBox');
  const bootDone = $('#bootDone');
  const bootState = $('#bootState');
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hideBoot = () => {
    if (!bootScreen || bootScreen.classList.contains('is-done')) return;
    bootScreen.classList.add('is-done');
    document.body.classList.add('app-ready');
    window.setTimeout(() => bootScreen.remove(), 650);
  };
  if (prefersReducedMotion) {
    hideBoot();
  } else {
    window.setTimeout(() => {
      if (bootBox) bootBox.style.opacity = '0';
      if (bootState) bootState.classList.add('is-changing');
      window.setTimeout(() => {
        if (bootDone) bootDone.classList.add('show');
        if (bootState) {
          bootState.textContent = 'ГОТОВО';
          bootState.classList.remove('is-changing');
          bootState.classList.add('is-ready');
        }
      }, 230);
    }, 1050);
    window.setTimeout(hideBoot, 1900);
    // Предохранитель: заставка не перекроет страницу при медленном/ошибочном скрипте.
    window.setTimeout(hideBoot, 3500);
  }

  const year = $('#year');
  if (year) year.textContent = String(new Date().getFullYear());
})();
